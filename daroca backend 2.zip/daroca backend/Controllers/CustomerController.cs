using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

[Route("/[controller]")]
[ApiController]
public class CustomerController : ControllerBase
{
    private readonly DatabaseContext context;

    public CustomerController(DatabaseContext context)
    {
        this.context = context;
    }

    [HttpGet]
    public ActionResult<IEnumerable<Customer>> GetCustomer()
    {
        return this.context.Customer.ToList();
    }

    [HttpGet("{id}")]
    public ActionResult<Customer> GetCustomer(int id)
    {
        var customer = this.context.Customer.Find(id);

        if(customer == null)
        {
            return NotFound();
        }

        return customer;
    }

    [HttpPost]
    public ActionResult<Customer> CreateCustomer(Customer customer)
    {
        if(customer == null)
        {
            return BadRequest();
        }

        this.context.Customer.Add(customer);
        this.context.SaveChanges();
        return CreatedAtAction(nameof(GetCustomer), new {id = customer.Id}, customer);
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteCustomer(int id)
    {
        var customer = context.Customer.Find(id);

        if (customer == null)
        {
            return NotFound();
        }

        context.Customer.Remove(customer);
        context.SaveChanges();
        return NoContent();
    }
}